from opencad import Part, Sketch

OPERATIONS = [{'shape': 'box', 'operation': 'add', 'size': {'x_mm': 92.0, 'y_mm': 64.0, 'z_mm': 4.0}, 'center': {'x_mm': 0.0, 'y_mm': 0.0, 'z_mm': 2.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'add', 'size': {'x_mm': 82.0, 'y_mm': 56.0, 'z_mm': 16.0}, 'center': {'x_mm': 0.0, 'y_mm': 0.0, 'z_mm': 11.0}, 'axis_labels': False}, {'shape': 'cylinder', 'operation': 'add', 'size': {'x_mm': 33.0, 'y_mm': 33.0, 'z_mm': 6.0}, 'center': {'x_mm': -15.0, 'y_mm': 0.0, 'z_mm': 19.0}, 'axis_labels': False}, {'shape': 'cylinder', 'operation': 'add', 'size': {'x_mm': 24.0, 'y_mm': 24.0, 'z_mm': 24.0}, 'center': {'x_mm': -15.0, 'y_mm': 0.0, 'z_mm': 34.0}, 'axis_labels': False}, {'shape': 'cylinder', 'operation': 'add', 'size': {'x_mm': 6.0, 'y_mm': 6.0, 'z_mm': 4.0}, 'center': {'x_mm': -34.0, 'y_mm': -22.0, 'z_mm': 19.0}, 'axis_labels': False}, {'shape': 'cylinder', 'operation': 'add', 'size': {'x_mm': 6.0, 'y_mm': 6.0, 'z_mm': 4.0}, 'center': {'x_mm': -34.0, 'y_mm': 22.0, 'z_mm': 19.0}, 'axis_labels': False}, {'shape': 'cylinder', 'operation': 'add', 'size': {'x_mm': 6.0, 'y_mm': 6.0, 'z_mm': 4.0}, 'center': {'x_mm': 34.0, 'y_mm': -22.0, 'z_mm': 19.0}, 'axis_labels': False}, {'shape': 'cylinder', 'operation': 'add', 'size': {'x_mm': 6.0, 'y_mm': 6.0, 'z_mm': 4.0}, 'center': {'x_mm': 34.0, 'y_mm': 22.0, 'z_mm': 19.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'cut', 'size': {'x_mm': 19.0, 'y_mm': 2.6, 'z_mm': 7.0}, 'center': {'x_mm': 19.0, 'y_mm': -15.0, 'z_mm': 18.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'cut', 'size': {'x_mm': 19.0, 'y_mm': 2.6, 'z_mm': 7.0}, 'center': {'x_mm': 19.0, 'y_mm': -9.0, 'z_mm': 18.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'cut', 'size': {'x_mm': 19.0, 'y_mm': 2.6, 'z_mm': 7.0}, 'center': {'x_mm': 19.0, 'y_mm': -3.0, 'z_mm': 18.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'cut', 'size': {'x_mm': 19.0, 'y_mm': 2.6, 'z_mm': 7.0}, 'center': {'x_mm': 19.0, 'y_mm': 3.0, 'z_mm': 18.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'cut', 'size': {'x_mm': 19.0, 'y_mm': 2.6, 'z_mm': 7.0}, 'center': {'x_mm': 19.0, 'y_mm': 9.0, 'z_mm': 18.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'cut', 'size': {'x_mm': 19.0, 'y_mm': 2.6, 'z_mm': 7.0}, 'center': {'x_mm': 19.0, 'y_mm': 15.0, 'z_mm': 18.0}, 'axis_labels': False}, {'shape': 'box', 'operation': 'cut', 'size': {'x_mm': 17.0, 'y_mm': 2.2, 'z_mm': 3.0}, 'center': {'x_mm': -15.0, 'y_mm': 0.0, 'z_mm': 46.0}, 'axis_labels': False}]
# Closed outlines in a unit square; no system fonts are needed.
GLYPHS = {
    "X": [(0,0),(.2,0),(.5,.35),(.8,0),(1,0),(.62,.5),(1,1),(.8,1),(.5,.65),(.2,1),(0,1),(.38,.5)],
    "Y": [(.4,0),(.6,0),(.6,.42),(1,1),(.78,1),(.5,.62),(.22,1),(0,1),(.4,.42)],
    "Z": [(0,0),(1,0),(1,.18),(.28,.18),(1,.82),(1,1),(0,1),(0,.82),(.72,.82),(0,.18)],
}

def engrave(part, letter, plane, origin, u, v, size, depth):
    points = [(u + (x-.5)*size, v + (y-.5)*size) for x,y in GLYPHS[letter]]
    sketch = Sketch(plane=plane, origin=origin, name=letter + " label outline")
    for start, end in zip(points, points[1:] + points[:1]):
        sketch.line(start, end)
    cutter = Part(name=letter + " engraving").extrude(sketch, depth=depth + .01)
    return part.cut(cutter, name=letter + " engraved face")

model = None
for index, item in enumerate(OPERATIONS):
    x,y,z = (item["center"][key] for key in ("x_mm","y_mm","z_mm"))
    sx,sy,sz = (item["size"][key] for key in ("x_mm","y_mm","z_mm"))
    profile = Sketch(plane="XY", origin=(0,0,z-sz/2), name="Solid profile " + str(index))
    if item["shape"] == "box":
        profile.rect(sx, sy, origin=(x-sx/2,y-sy/2))
    else:
        profile.circle(sx/2, center=(x,y))
    part = Part(name=item["shape"]).extrude(profile, depth=sz)
    if item["axis_labels"]:
        depth = min(.5, min(sx,sy,sz)/20)
        part = engrave(part, "X", "YZ", (x+sx/2-depth,0,0), y,z,min(sy,sz)*.45,depth)
        part = engrave(part, "Y", "XZ", (0,y+sy/2-depth,0), x,z,min(sx,sz)*.45,depth)
        part = engrave(part, "Z", "XY", (0,0,z+sz/2-depth), x,y,min(sx,sy)*.45,depth)
    if model is None:
        model = part
    elif item["operation"] == "cut":
        model = model.cut(part, name="Cut " + str(index))
    else:
        model = model.union(part, name="Union " + str(index))

model
